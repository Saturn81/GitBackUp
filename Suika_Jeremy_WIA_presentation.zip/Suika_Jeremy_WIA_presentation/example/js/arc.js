var $font = $('.font').hide();
var $font2 = $('.font2').hide();
var $font3 = $('.font3').hide();


	
	google.load('webfont','1');
	
	google.setOnLoadCallback(function() {
		WebFont.load({
			google		: {
				families	: ['','Concert One']
			},
			fontactive	: function(fontFamily, fontDescription) {
				init();
			},
			fontinactive	: function(fontFamily, fontDescription) {
				init();
			}
		});
	});
	
	function init() {
	
		
		 $font.show().arctext({radius: 300, dir:1});	
		 $font2.show().arctext({radius: 300, dir: -1 });
		 //$font2.show().arctext({radius: 300, dir: -1, rotate: false});
		 $font3.show().arctext({radius: 100, dir: 1});
		  
		
		
			
	};




	

