var $font = $('#sample').hide();


	google.load('webfont','1');
	
	google.setOnLoadCallback(function() {
		WebFont.load({
			google		: {
				families	: ['','Concert One']
			},
			fontactive	: function(fontFamily, fontDescription) {
				init();
			},
			fontinactive	: function(fontFamily, fontDescription) {
				init();
			}
		});
	});
	
	function init() {
	
		
		 $font.show().arctext({radius: 200, dir:-1});	
		
	
	$('#animate').on('click', function() {
		$font.arctext('set', {
			radius		:500, 
			dir			: -1,
			animation	: {
				speed	: 700,
				easing  : 'ease-out'
			}
		});
		return false;
		});
		
		};



	

